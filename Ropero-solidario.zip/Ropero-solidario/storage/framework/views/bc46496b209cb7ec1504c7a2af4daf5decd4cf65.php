<!DOCTYPE html>
<html>
<head>
	<title>Nosotros</title>
	<link rel="stylesheet" href="<?php echo e(URL::asset('../../public/css/home.css')); ?>" />
	<link rel="icon" type="image/png" href="img/icono.png">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body class="fondo-nosotros">

<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div  class="formulario-registracion">

<h1>SOBRE NOSOTROS</h1>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec consectetur tellus dolor, in commodo nisl posuere a. Phasellus velit elit, pulvinar rutrum lorem eu, vestibulum feugiat dolor. Vestibulum lobortis facilisis magna quis ornare. Ut ut libero mauris. Nunc efficitur erat in nisi dictum ultrices. Aliquam semper justo at hendrerit sagittis. Curabitur ornare felis et tristique sagittis. Praesent nec libero quis neque tempor consequat vitae sed lacus.
</p>

<br>
<p>Donec luctus risus ut erat consectetur, quis gravida dolor ultrices. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla placerat, tellus et sodales consectetur, ligula lorem blandit ipsum, a vehicula ligula dui finibus leo. Suspendisse suscipit auctor aliquam. Pellentesque libero nunc, tincidunt vitae sagittis id, porttitor vel turpis. Nam euismod felis id purus hendrerit, sed sagittis est auctor. Nulla ac nisl ex. Vestibulum congue sit amet dolor sit amet malesuada. Cras maximus libero nec mollis sodales. </p>


</div>


<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
