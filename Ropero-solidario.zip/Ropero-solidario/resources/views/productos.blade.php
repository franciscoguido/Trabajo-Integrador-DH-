<!DOCTYPE html>
<html>
<head>
	<title>Productos</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="utf-8">
	<link rel="icon" type="image/png" href="public/img/icono.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>

@include('header')

<div class="#">                   
  <ol class="breadcrumb">
    <li><a href="home.blade.php">Home</a></li>
    <li><a href="productos.blade.php">Productos</a></li>
    <li class="active">Mujer</li>        
  </ol>
</div>




@include('footer')

</body>
</html>