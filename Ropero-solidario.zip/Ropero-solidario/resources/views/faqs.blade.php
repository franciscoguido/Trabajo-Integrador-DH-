<!DOCTYPE html>
<html>
<head>
	<title>Faqs</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link rel="stylesheet" type="text/css" href="Ropero-solidario/public/css/faqs.css">
	<link rel="icon" type="image/png" href="grafica/icono.png">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
<!--     HEADER    -->

@include('header')

<!--     SECTION   -->

			<div class="faqs">
				<section id="faqs2">
				<h4 class="subtitulo4" >Donación</h4>
					<ul>


						<h5 class="subtitulo5">¿Cómo puedo donar?</h5>
							<ul class="donacion">

								<h6 class="tiempo">Mensualmente</h6>
									<ul>
										<li class="lidonar">Mirá las Causas Sociales a las que podés ayudar. Elegí la que más te guste para donar mensualmente a través de nuestra web.</li> <br>

										<li class="lidonar">Suscribite al Plan Solidario Mensual que quieras y recibí puntos.</li> <br>

										<li class="lidonar">Los puntos que recibiste los podés cambiar por beneficios. $1 equivale a 10 puntos. Se te van a cargar los puntos automáticamente todos los meses.</li> <br>

										<li class="lidonar">Elegí los beneficios que más te gusten y canjealos por tus puntos. Lo podés hacer en el momento o simplemente tener los puntos cargados y elegir más adelante. Los puntos no se vencen y son acumulables.</li> <br>

										<li class="lidonar" >Recibí el voucher de tus beneficios en tu email.</li> <br>

										<li class="lidonar">Presentá tu voucher en el local antes de hacer el pedido. Lo podés hacer desde tu celular o impreso. No se necesita reserva salvo que se especifique como excepción.</li> <br>

										<li class="lidonar">¡Disfrutá!</li> <br>
									</ul>


								<h6 class="tiempo">Por única vez (sólo cuando haya eventos)</h6>
									<ol>
										<li class="lidonar">Entrá a la sección eventos. Solo va a estar visible si hay un evento vigente.</li> <br>

										<li class="lidonar" >Elegí los beneficios que quieras consumir en el mismo.</li> <br>

										<li class="lidonar">Doná el monto a pagar a la causa social con la que quieras colaborar.</li> <br>

										<li class="lidonar">Realizá el pago a través de Mercadopago. Sólo se aceptan tarjetas de crédito.</li> <br>

										<li class="lidonar">Recibí el voucher de tus beneficios en tu email.</li> <br>

										<li class="lidonar">Presentá tu voucher antes de hacer el pedido. Lo podés hacer desde tu celular o impreso.</li> <br>

										<li class="lidonar">¡Disfrutá!</li><br>
									</ol>
							</ul>

						<h5 class="subtitulo5" >¿Cómo se invierte mi donación?</h5>
							<ol>
								<li class="li-faqs">
									La ONG a la cual decidiste donar es la encargada de elegir a qué parte de su proyecto social destina tu colaboración.</li> <br>
							</ol>

						<h5 class="subtitulo5" >¿Cómo me entero de lo que se hizo con mi donación?</h5>
							<ul>
								<li class="li-faqs">
									Te vamos a mandar un mail, en los primeros días del mes, para contarte qué va a hacer con lo que recaudó la ONG a la cual contribuiste.
								</li>

							</ul> <br>

						<h5 class="subtitulo5" >¿Puedo donar a una ONG diferente por mes?</h5>
							<ul>
								<li class="li-faqs">
									¡Sí, podés! Vas a tener que cambiar en tu perfil la ONG con la que querés colaborar. La ONG que tengas cargada en tu perfil el último día del mes, es a la que se va a dirigir tu donación.
								</li>

							</ul> <br>

						<h5 class="subtitulo5" >¿Puedo donar a más de una ONG?</h5>

							<ul>
								<li class="li-faqs">
									Sí, sólo tenés que crear más de un débito automático y cada uno de ellos se asocia a una ONG diferente. Por ejemplo, si querés donar a través de Glupa 200 pesos por mes: creás un débito por 100 pesos a “X” ONG y otro por 100 pesos a “XX” ONG. En total, todos los meses vas a tener un débito de 200 pesos y vas a ayudar a ONGs diferentes.
								</li><br>
							</ul>
					</ul>



				<h4 class="subtitulo4" >Beneficios</h4>

					<ul class="beneficios">


							<h5 class="subtitulo5" >¿Cuál es la relación entre el monto que dono y los puntos que recibo?</h5>
								<li class="li-faqs">
									1 peso equivale a 10 puntos. Si bien del monto que dones a través de nuestra web el 65% va a la ONG y el 35% a nuestra web, vas a obtener puntos por el total de la transacción.
								</li> <br>

							<h5 class="subtitulo5" >¿Existe un mínimo para donar a través de la web?</h5>
								<li class="li-faqs">Si, el mínimo es de 50 pesos.</li> <br>

							<h5 class="subtitulo5" >¿Cómo utilizo el voucher?</h5>
								<li class="li-faqs">
									Es muy sencillo: después de elegir tu beneficio y cambiarlo por tus puntos, vas a recibir un email con el voucher. Lo tenés que presentar en el local antes de hacer tu pedido. Lo podés presentar desde tu celular o llevarlo impreso.* <br>

									*Tip: ¡Cuidemos el medio ambiente! Recomendamos que lo muestres desde el celular.class="subtitulo5"
								</li> <br>

							<h5 class="subtitulo5">¿Es obligatorio imprimir mi voucher?</h5>
								<li class="li-faqs">
									No, no es obligatorio. Simplemente mostrando el email al local podés disfrutar de tu beneficio.
									¡No te olvides de presentar el voucher antes de hacer tu pedido!
								</li> <br>
							<h5 class="subtitulo5">¿Tengo que reservar?</h5>
								<li class="li-faqs">
									No, no es necesario hacer reserva, sólo en casos excepcionales en los cuales te lo vamos a hacer saber. ¡Prestá atención a las condiciones del beneficio!
								</li> <br>

							<h5 class="subtitulo5">¿Hay alguna restricción sobre cuándo puedo usar mi voucher?</h5>
								<li class="li-faqs">
									La restricción está indicada en el voucher y en las condiciones del beneficio.
								</li><br>
							<h5 class="subtitulo5">¿Tengo que usar el voucher el día que lo compro?</h5>
								<li class="li-faqs">
									No necesariamente. Disfrutá del beneficio cuando quieras antes de la fecha de vencimiento del voucher.</li> <br>
							<h5 class="subtitulo5">¿Puedo regalar los vouchers?</h5>
								<li class="li-faqs">
									¡Podés regalárselo a quien quieras cuando quieras! Simplemente enviale a la persona a la que se lo querés regalar el email que te llegó con el código.
								</li><br>
							<h5 class="subtitulo5">Me arrepentí y no quiero el beneficio ¿Me devuelven los puntos?</h5>
								<li class="li-faqs">
								¡No hay problema! Si nos avisás dentro del plazo de cinco días desde que adquiriste el beneficio, te hacemos la devolución de los puntos. Mandanos un mail a contacto@roperosolidario.org
								</li> <br>

							<h5 class="subtitulo5" >¿Los puntos son transferibles?</h5>
								<li class="li-faqs">
									No. Los puntos son personales e intransferibles.
								</li> <br>
							<h5 class="subtitulo5">¿Se vencen los puntos?</h5>
								<li class="li-faqs">
									No solo no se te vencen, ¡sino que se te acumulan! Si un mes no utilizaste todos tus puntos, se te van a acumular con los puntos de los meses siguientes, hasta que los utilices.
								</li><br>
				</ul>

				<h4 class="subtitulo4" >Pago</h4>
					<ul class="pago">
						<h5 class="subtitulo5" >¿Es seguro comprar en este sitio?</h5>
							<li class="li-faqs">
								Es muy seguro. Cobramos a través de MERCADOPAGO, una de las plataformas más usadas y seguras de pagos online de Latinoamérica.
						   	</li> <br>

						<h5 class="subtitulo5">¿A que cuenta va mi donación?</h5>
						<li class="li-faqs">
							Tu donación va directamente a la ONG que decidiste ayudar a una cuenta que ellos tienen en MERCADOSOLIDARIO
						</li> <br>

						<h5 class="subtitulo5">¿Cómo aparece en mi resumen de la tarjeta la donación a través de este sitio?</h5>
							<li class="li-faqs">
								Nos encantaría que puedas ver en el resumen de tu tarjeta a la ONG a la que estás colaborando. Por cuestiones ajenas a nosotros te va a aparecer como un débito de Mercadolibre.
							</li><br>

						<h5 class="subtitulo5">¿Puedo descontar mi donación de impuestos a las ganancias?</h5>
						<li class="li-faqs">Si podés.</li> <br>

						<h5 class="subtitulo5">¿Puedo darme de baja de la suscripción mensual a través de este sitio?</h5>
						<li class="li-faqs">¡Si. Tenés que mandarnos un email a contacto@estesitio.com diciendo que querés darte de baja. Si lo hacés por algo que no te haya gustado de este sitio, te agradeceríamos que nos cuentes. Nos encanta escuchar la opinión de la gente para seguir aprendiendo y dando un mejor servicio para mejorar la sociedad juntos.</li> <br>

						<h5 class="subtitulo5">¿Cómo se sostiene económicamente este sitio?</h5>
						<li class="li-faqs">Este sitio factura a las ONGs un porcentaje de lo donado por el servicio de fundraising. </li><br>

						<h5 class="subtitulo5">¿Qué hago si no encuentro mi pregunta acá?</h5>
						<li class="li-faqs">Mandanos tu pregunta a contacto@estesitio.com ¡Te la vamos a responder cuanto antes!</li>
					</ul>

				</section>
			</div>


<!--     FOOTER   -->

@include('footer')

	</body>

	</html>
