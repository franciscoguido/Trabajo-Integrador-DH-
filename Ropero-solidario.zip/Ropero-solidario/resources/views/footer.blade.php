
	<nav class="navbar navbar-inverse fixed-footer">
		<ul class="nav navbar-nav">
			<li><a href="faqs">Preguntas Frecuentes</a></li>
			<li><a href="terminos">Terminos y Condiciones</a></li>
			<li><a href="contacto">Contacto</a></li>
		</ul>
	</nav>

