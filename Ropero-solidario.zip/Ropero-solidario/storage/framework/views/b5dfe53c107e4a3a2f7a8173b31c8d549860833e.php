<!DOCTYPE html>
<html>
<head>
	<title>Footer</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="utf-8">
	<link rel="icon" type="image/png" href="grafica/icono.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>

	<nav class="navbar navbar-inverse">
		<ul class="nav navbar-nav">
			<li><a href="faqs.blade.php">Preguntas Frecuentes</a></li>
			<li><a href="terminos.blade.php">Terminos y Condiciones</a></li>
			<li><a href="contacto.blade.php">Contacto</a></li>
		</ul>
	</nav>

</body>
</html>