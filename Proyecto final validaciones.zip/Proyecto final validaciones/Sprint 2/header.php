<!DOCTYPE html>
<html>
<head>
	<title>Home Principal</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
<div class="container">

	<header class="main-header">
	<a href="home.html"><img src="./grafica/Logo-prueba.png" alt="logotipo" class="logo"></a>

		<nav class="main-nav">
			<a href="#" id="menu-icon" src="./grafica/icono-hamburgesa.png"></a>

			<ul>			
			  <li><a href="como funciona.html">Como funciona</a></li>
			  <li><a href="causas.html">Causas</a></li>
			  <li><a href="beneficios.html">Beneficios</a></li>
			  <li><a href="contacto.html" >Contacto</a></li>
			  <li><a href="donar.html" style="color: #CC0000">Donar</a></li>
			  <li><a href="ingresar.html" style="color: #CC0000" >Ingresar</a></li>			  
			</ul>
		</nav>
		
</header>