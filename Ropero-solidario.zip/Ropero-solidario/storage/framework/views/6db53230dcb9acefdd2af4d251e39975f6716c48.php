<!DOCTYPE html>
<html>
<head>
	<title>Productos</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="utf-8">
	<link rel="icon" type="image/png" href="public/img/icono.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>

<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="#">                   
  <ol class="breadcrumb">
    <li><a href="home.blade.php">Home</a></li>
    <li><a href="productos.blade.php">Productos</a></li>
    <li class="active">Mujer</li>        
  </ol>
</div>




<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>