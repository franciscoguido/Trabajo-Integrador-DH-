<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductosMujeresController extends Controller
{
	public function mostrar () {
		return view('mujeres');

	}
}